namespace Socialmedia.Utilities;

public enum TableNames
{
    user,
    users,
    post,
    hashtag,
    like,
    post_hashtag,
}